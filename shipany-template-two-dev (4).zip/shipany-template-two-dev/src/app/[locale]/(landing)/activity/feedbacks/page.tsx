export default function FeedbacksPage() {
  return <div>feedbacks</div>;
}
