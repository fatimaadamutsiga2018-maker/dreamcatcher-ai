import { ChatGenerator } from '@/shared/blocks/chat/generator';

export default function ChatPage() {
  return <ChatGenerator />;
}
