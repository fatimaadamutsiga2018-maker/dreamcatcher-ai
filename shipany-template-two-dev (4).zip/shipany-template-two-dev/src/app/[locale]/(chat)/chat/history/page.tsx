import { ChatHistory } from '@/shared/blocks/chat/history';

export default function ChatHistoryPage() {
  return <ChatHistory />;
}
