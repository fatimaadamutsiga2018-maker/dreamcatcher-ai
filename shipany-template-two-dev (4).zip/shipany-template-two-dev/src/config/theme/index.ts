export const themeNames = ['default'];

export const defaultTheme = 'default';
